package com.epam.brest.springsecuritywithdynamic.auth;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringSecurityWithDynamicAuthApplicationTests {

	@Test
	void contextLoads() {
	}

}
